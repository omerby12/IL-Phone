const data123={
    products: [
        {
            name: 'Name1',
            slug:'dfsdfsdfsdfsf',
            category:'',
            image: '/images/p1.jpg',
            price: 120,
            countInStock:10,
            rating:4.5,
            numReviews:10,
            description: 'hig quality shirt',
        },
        {
            name: 'Name2',
            slug:'sdassa',
            category:'',
            image: '/images/p1.jpg',
            price: 120,
            countInStock:10,
            rating:4.5,
            numReviews:10,
            description: 'edad',
        },
  
    ]
  }
  export default data123;